package com.example.myapplicationwikiloc

class GoogleMap {
    fun addMarker(title: Any) {

    }

    fun moveCamera(newLatLng: Unit) {

    }

}
