package com.example.myapplicationwikiloc

class MarkerOptions {
    fun position(sydney: LatLng): Any {
        TODO("Not yet implemented")
    }

}
