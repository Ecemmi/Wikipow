package com.example.myapplicationwikiloc

class SupportMapFragment {
    fun <OnMapReadyCallback> getMapAsync(mainActivity: MainActivity<OnMapReadyCallback>) {

    }

}
