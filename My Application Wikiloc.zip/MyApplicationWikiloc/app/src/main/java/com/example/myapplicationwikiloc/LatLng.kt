package com.example.myapplicationwikiloc

class LatLng(i: Int, i1: Int) {

}
