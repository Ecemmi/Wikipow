package com.example.myapplicationwikiloc

class CameraUpdateFactory {
    companion object {
        fun newLatLng(sydney: LatLng) {

        }
    }

}
